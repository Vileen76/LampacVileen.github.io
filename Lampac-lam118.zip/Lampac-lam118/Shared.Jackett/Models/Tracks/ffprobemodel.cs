﻿using System.Collections.Generic;

namespace JacRed.Models.Tracks
{
    public class ffprobemodel
    {
        public List<ffStream> streams { get; set; }
    }
}
