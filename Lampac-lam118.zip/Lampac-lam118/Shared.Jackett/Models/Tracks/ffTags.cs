﻿namespace JacRed.Models.Tracks
{
    public class ffTags
    {
        public string language { get; set; }

        public string BPS { get; set; }

        public string DURATION { get; set; }

        public string title { get; set; }
    }
}
