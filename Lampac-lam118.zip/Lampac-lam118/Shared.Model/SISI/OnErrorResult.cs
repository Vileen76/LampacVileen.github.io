﻿namespace Shared.Model.SISI
{
    public class OnErrorResult
    {
        public bool error { get; set; } = true;

        public string? msg { get; set; }
    }
}
