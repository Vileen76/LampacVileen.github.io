﻿namespace Shared.Model.SISI.Xvideos
{
    public class Related
    {
        public string? u { get; set; }

        public string? i { get; set; }

        public string? d { get; set; }

        public string @if { get; set; }

        public string? tf { get; set; }


        public string? pn { get; set; }

        public string? p { get; set; }

        public bool ch { get; set; }
    }
}
