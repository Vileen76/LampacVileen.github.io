﻿namespace Shared.Model.SISI
{
    public class BookmarksConf
    {
        public bool saveimage { get; set; }

        public bool savepreview { get; set; }
    }
}
