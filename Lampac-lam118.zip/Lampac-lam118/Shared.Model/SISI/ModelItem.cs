﻿namespace Shared.Model.SISI
{
    public class ModelItem
    {
        public string uri { get; set; }

        public string name { get; set; }
    }
}
