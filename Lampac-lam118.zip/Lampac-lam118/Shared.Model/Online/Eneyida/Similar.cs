﻿namespace Shared.Model.Online.Eneyida
{
    public class Similar
    {
        public string title { get; set; }

        public string year { get; set; }

        public string href { get; set; }
    }
}
