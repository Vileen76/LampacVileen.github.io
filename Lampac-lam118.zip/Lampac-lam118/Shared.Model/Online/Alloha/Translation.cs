﻿namespace Lampac.Models.LITE.Alloha
{
    public class Translation
    {
        public string translation { get; set; }
    }
}
