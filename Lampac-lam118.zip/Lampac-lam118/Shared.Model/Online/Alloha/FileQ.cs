﻿namespace Shared.Model.Online.Alloha
{
    public class FileQ
    {
        public string h264 { get; set; }

        public string? av1 { get; set; }
    }
}
