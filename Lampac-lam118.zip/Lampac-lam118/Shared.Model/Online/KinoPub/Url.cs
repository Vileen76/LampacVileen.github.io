﻿namespace Lampac.Models.LITE.KinoPub
{
    public class Url
    {
        public string http { get; set; }

        public string hls { get; set; }

        public string hls4 { get; set; }

        public string hls2 { get; set; }
    }
}
