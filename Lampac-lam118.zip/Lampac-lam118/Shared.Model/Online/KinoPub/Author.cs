﻿namespace Lampac.Models.LITE.KinoPub
{
    public class Author
    {
        public string title { get; set; }
    }
}
