﻿namespace Shared.Model.Online.KinoPub
{
    public class SearchObject
    {
        public List<SearchItem> items { get; set; }
    }
}
