﻿namespace Lampac.Models.LITE.KinoPub
{
    public class RootObject
    {
        public int status { get; set; }

        public Item item { get; set; }
    }
}
