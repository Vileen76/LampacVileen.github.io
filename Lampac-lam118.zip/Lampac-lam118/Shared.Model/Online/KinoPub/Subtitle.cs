﻿namespace Lampac.Models.LITE.KinoPub
{
    public class Subtitle
    {
        public string lang { get; set; }

        public string url { get; set; }
    }
}
