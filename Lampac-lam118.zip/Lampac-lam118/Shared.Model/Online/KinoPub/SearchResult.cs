﻿namespace Shared.Model.Online.KinoPub
{
    public class SearchResult
    {
        public int id { get; set; }

        public string? similars { get; set; }
    }
}
