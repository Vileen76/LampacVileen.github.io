﻿namespace Lampac.Models.LITE.KinoPub
{
    public class File
    {
        public string quality { get; set; }

        public string file { get; set; }

        public Url url { get; set; }
    }
}
