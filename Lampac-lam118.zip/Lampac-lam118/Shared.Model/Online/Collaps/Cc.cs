﻿namespace Lampac.Models.LITE.Collaps
{
    public class Cc
    {
        public string? url { get; set; }

        public string? name { get; set; }
    }
}
