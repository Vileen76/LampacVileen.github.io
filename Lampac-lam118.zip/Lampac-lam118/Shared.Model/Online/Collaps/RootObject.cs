﻿namespace Lampac.Models.LITE.Collaps
{
    public class RootObject
    {

        public int season { get; set; }

        public List<Episode>? episodes { get; set; }
    }
}
