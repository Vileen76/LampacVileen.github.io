﻿namespace Lampac.Models.LITE.Collaps
{
    public class Audio
    {
        public List<string>? names { get; set; }
    }
}
