﻿namespace Shared.Model.Online.Filmix
{
    public class SearchResult
    {
        public int id { get; set; }

        public string? similars { get; set; }
    }
}
