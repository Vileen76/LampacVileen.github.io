﻿namespace Lampac.Models.LITE.Filmix
{
    public class RootObject
    {
        public PlayerLinks? player_links { get; set; }

        public string? quality { get; set; }
    }
}
