﻿namespace Shared.Model.Online.Filmix
{
    public class SearchModel
    {
        public int id { get; set; }

        public string? title { get; set; }

        public string? original_title { get; set; }

        public int year { get; set; }
    }
}
