﻿namespace Shared.Model.Online.Redheadsound
{
    public class EmbedModel
    {
        public bool IsEmpty { get; set; }

        public string iframe { get; set; }

        public string iframeUri { get; set; }
    }
}
