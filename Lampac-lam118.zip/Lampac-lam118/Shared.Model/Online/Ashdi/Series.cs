﻿namespace Lampac.Models.LITE.Ashdi
{
    public class Series
    {
        public string title { get; set; }

        public string file { get; set; }

        public string subtitle { get; set; }
    }
}
