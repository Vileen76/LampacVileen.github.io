﻿using System.Collections.Generic;

namespace Lampac.Models.LITE.Ashdi
{
    public class Voice
    {
        public string title { get; set; }

        public List<Season> folder { get; set; }
    }
}
