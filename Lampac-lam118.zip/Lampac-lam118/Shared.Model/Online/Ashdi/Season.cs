﻿using System.Collections.Generic;

namespace Lampac.Models.LITE.Ashdi
{
    public class Season
    {
        public string title { get; set; }

        public List<Series> folder { get; set; }
    }
}
