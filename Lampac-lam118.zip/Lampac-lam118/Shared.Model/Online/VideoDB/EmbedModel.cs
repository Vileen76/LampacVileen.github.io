﻿namespace Shared.Model.Online.VideoDB
{
    public class EmbedModel
    {
        public List<RootObject> pl { get; set; }

        public bool movie { get; set; }

        public bool obfuscation { get; set; }

        public string quality { get; set; }
    }
}
