﻿namespace Shared.Model.Online.Zetflix
{
    public class Folder
    {
        public string comment { get; set; }

        public string file { get; set; }
    }
}
