﻿namespace Shared.Model.Online.Zetflix
{
    public class EmbedModel
    {
        public List<RootObject> pl { get; set; }

        public bool movie { get; set; }

        public string quality { get; set; }

        public string? check_url { get; set; }
    }
}
