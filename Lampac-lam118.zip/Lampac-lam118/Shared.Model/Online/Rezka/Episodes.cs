﻿namespace Shared.Model.Online.Rezka
{
    public class Episodes
    {
        public string episodes { get; set; }

        public string seasons { get; set; }
    }
}
