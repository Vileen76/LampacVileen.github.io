﻿namespace Shared.Model.Online.VoKino
{
    public class Similar
    {
        public string title { get; set; }

        public string balancer { get; set; }
    }
}
