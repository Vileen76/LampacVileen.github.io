﻿namespace Shared.Model.Online.VoKino
{
    public class ViewOnline
    {
        public bool vokino { get; set; } = true;

        public bool filmix { get; set; } = true;

        public bool alloha { get; set; } = true;

        public bool zetflix { get; set; } = true;

        public bool videocdn { get; set; } = true;

        public bool ashdi { get; set; } = true;

        public bool rhs { get; set; } = true;

        public bool collaps { get; set; } = true;
    }
}
