﻿namespace Shared.Model.Online.VoKino
{
    public class RootObject
    {
        public List<Сhannel>? menu { get; set; }

        public List<Сhannel> channels { get; set; }
    }
}
