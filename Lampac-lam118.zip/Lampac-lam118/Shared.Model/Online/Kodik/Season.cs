﻿namespace Lampac.Models.LITE.Kodik
{
    public class Season
    {
        public string link { get; set; }

        public Dictionary<string, string> episodes { get; set; }
    }
}
