﻿namespace Shared.Model.Online.Kodik
{
    public class EmbedModel
    {
        public string? html { get; set; }

        public List<Result>? result { get; set; }
    }
}
