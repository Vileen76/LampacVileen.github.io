﻿namespace Shared.Model.Online.Kodik
{
    public class StreamModel
    {
        public string q { get; set; }

        public string url { get; set; }
    }
}
