﻿namespace Shared.Model.Online.Kodik
{
    public class RootObject
    {
        public List<Result> results { get; set; }
    }
}
