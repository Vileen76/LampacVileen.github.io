﻿namespace Shared.Model.Online.Kodik
{
    public class Translation
    {
        public string title { get; set; }
    }
}
