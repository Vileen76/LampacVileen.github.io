﻿namespace Lampac.Models.LITE.CDNmovies
{
    public class Episode
    {
        public string title { get; set; }

        public string file { get; set; }
    }
}
