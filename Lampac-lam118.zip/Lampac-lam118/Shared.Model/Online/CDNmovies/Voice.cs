﻿namespace Lampac.Models.LITE.CDNmovies
{
    public class Voice
    {
        public string title { get; set; }

        public List<Season> folder { get; set; }
    }
}
