﻿namespace Lampac.Models.LITE.CDNmovies
{
    public class Season
    {
        public string title { get; set; }

        public List<Episode> folder { get; set; }
    }
}
