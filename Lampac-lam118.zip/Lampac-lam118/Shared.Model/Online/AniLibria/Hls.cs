﻿namespace Lampac.Models.LITE.AniLibria
{
    public class Hls
    {
        public string fhd { get; set; }

        public string hd { get; set; }

        public string sd { get; set; }
    }
}
