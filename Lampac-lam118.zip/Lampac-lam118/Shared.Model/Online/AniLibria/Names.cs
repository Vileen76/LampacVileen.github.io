﻿namespace Lampac.Models.LITE.AniLibria
{
    public class Names
    {
        public string ru { get; set; }

        public string en { get; set; }
    }
}
