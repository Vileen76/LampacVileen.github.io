﻿namespace Lampac.Models.LITE.AniLibria
{
    public class RootObject
    {
        public Names names { get; set; }

        public string code { get; set; }

        public Season season { get; set; }

        public Player player { get; set; }
    }
}
