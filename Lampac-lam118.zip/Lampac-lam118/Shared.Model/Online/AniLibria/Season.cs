﻿namespace Lampac.Models.LITE.AniLibria
{
    public class Season
    {
        public int year { get; set; }
    }
}
