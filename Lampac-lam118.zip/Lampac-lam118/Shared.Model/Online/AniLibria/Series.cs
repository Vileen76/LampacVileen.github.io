﻿namespace Lampac.Models.LITE.AniLibria
{
    public class Series
    {
        public int serie { get; set; }

        public Hls hls { get; set; }
    }
}
