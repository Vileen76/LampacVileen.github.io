﻿namespace Shared.Model.Online.VDBmovies
{
    public class RootObject
    {
        public Dictionary<string, Movie>? data { get; set; }
    }
}
