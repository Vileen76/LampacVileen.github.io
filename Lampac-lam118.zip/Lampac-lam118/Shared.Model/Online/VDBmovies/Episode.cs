﻿namespace Shared.Model.Online.VDBmovies
{
    public class Episode
    {
        public string title { get; set; }

        public string file { get; set; }

        public string? subtitle { get; set; }
    }
}
