﻿namespace Shared.Model.Online.VDBmovies
{
    public class Movie
    {
        public string? iframe_src { get; set; }
    }
}
