﻿namespace Shared.Model.Online.VideoCDN
{
    public class SearchRoot
    {
        public List<Datum>? data { get; set; }
    }
}
