﻿namespace Shared.Model.Online.VideoCDN
{
    public class Season
    {
        public int id { get; set; }

        public List<Folder> folder { get; set; }
    }
}
