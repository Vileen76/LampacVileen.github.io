﻿namespace Shared.Model.Online.VideoCDN
{
    public class Folder
    {
        public string id { get; set; }

        public string file { get; set; }
    }
}
