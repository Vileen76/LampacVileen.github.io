﻿namespace Shared.Model.Base
{
    public interface Iproxy
    {
        public bool useproxy { get; set; }

        public bool useproxystream { get; set; }

        public string? globalnameproxy { get; set; }

        public ProxySettings? proxy { get; set; }
    }
}
