﻿namespace Shared.Model.Base
{
    public class ProxyAction
    {
        public string url;
        public string data;
        public string contains;

        public int timeoutSeconds = 5;
    }
}
