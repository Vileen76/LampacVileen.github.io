﻿namespace Shared.Model.Base
{
    public class ApnConf
    {
        public string? host { get; set; }

        public string secure { get; set; }

        public string secret { get; set; }
    }
}
