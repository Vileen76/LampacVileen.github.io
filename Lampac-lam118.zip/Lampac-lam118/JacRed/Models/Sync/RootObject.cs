﻿using System.Collections.Generic;

namespace JacRed.Models.Sync
{
    public class RootObject
    {
        public bool nextread { get; set; }

        public List<Collection> collections { get; set; }
    }
}
