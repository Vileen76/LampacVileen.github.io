﻿namespace JacRed.Models.Sync
{
    public class Collection
    {
        public string Key { get; set; }

        public Value Value { get; set; }
    }
}
