﻿namespace Lampac.Models.JAC
{
    public class LoginSettings
    {
        public string u { get; set; }

        public string p { get; set; }
    }
}
