﻿namespace Lampac.Models.JAC.AniLibria
{
    public class Quality
    {
        public string @string { get; set; }

        public int resolution { get; set; }

        public string encoder { get; set; }
    }
}
