﻿namespace Lampac.Models.JAC.AniLibria
{
    public class Names
    {
        public string ru { get; set; }

        public string en { get; set; }
    }
}
