﻿namespace Lampac.Models.JAC.AniLibria
{
    public class Series
    {
        public string @string { get; set; }
    }
}
