﻿namespace Lampac.Models.JAC.AniLibria
{
    public class Season
    {
        public int year { get; set; }

        public int code { get; set; }
    }
}
