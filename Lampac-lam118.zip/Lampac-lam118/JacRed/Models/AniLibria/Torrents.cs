﻿using System.Collections.Generic;

namespace Lampac.Models.JAC.AniLibria
{
    public class Torrents
    {
        public List<Torrent> list { get; set; }
    }
}
