﻿namespace Lampac.Model.SISI.BongaCams
{
    public class LocalData
    {
        public string videoServerUrl { get; set; }
    }
}
