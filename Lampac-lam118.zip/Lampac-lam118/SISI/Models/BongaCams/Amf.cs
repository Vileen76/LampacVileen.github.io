﻿namespace Lampac.Model.SISI.BongaCams
{
    public class Amf
    {
        public LocalData localData { get; set; }
    }
}
