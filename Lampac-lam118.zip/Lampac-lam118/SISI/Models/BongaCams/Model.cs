﻿namespace Lampac.Model.SISI.BongaCams
{
    public class Model
    {
        public bool online { get; set; }

        public string username { get; set; }

        public string display_name { get; set; }

        public string topic { get; set; }

        public string thumb_image { get; set; }

        public string room { get; set; }

        public int hd_cam { get; set; }

        public int hd_plus { get; set; }

        public bool is_away { get; set; }
    }
}
