﻿using System.Collections.Generic;

namespace Lampac.Model.SISI.BongaCams
{
    public class Listing
    {
        public List<Model> models { get; set; }

        public int online_count { get; set; }
    }
}
