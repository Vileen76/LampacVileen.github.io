﻿using System.Collections.Generic;

namespace Lampac.Models.Merchant.LtcWallet
{
    public class RootTransactions
    {
        public List<Transaction> result { get; set; }
    }
}
