﻿namespace Lampac.Models.Merchant
{
    public class CryptoCloudConf
    {
        public bool enable { get; set; }

        public string SHOPID { get; set; }

        public string APIKEY { get; set; }

        public string SECRETKEY { get; set; }
    }
}
