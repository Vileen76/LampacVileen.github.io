﻿namespace Lampac.Models.Merchant
{
    public class FreekassaConf
    {
        public bool enable { get; set; }

        public long shop_id { get; set; }

        public string secret { get; set; }
    }
}
