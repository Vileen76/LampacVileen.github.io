﻿namespace Lampac.Models.Module
{
    public class SisiMod
    {
        public bool enable { get; set; }

        public string name { get; set; }

        public string url { get; set; }
    }
}
