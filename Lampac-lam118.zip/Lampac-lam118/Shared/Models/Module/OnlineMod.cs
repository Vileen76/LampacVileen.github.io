﻿namespace Lampac.Models.Module
{
    public class OnlineMod
    {
        public bool enable { get; set; }

        public string @namespace { get; set; }
    }
}
