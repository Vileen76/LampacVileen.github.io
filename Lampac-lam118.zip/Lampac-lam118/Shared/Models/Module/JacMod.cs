﻿namespace Lampac.Models.Module
{
    public class JacMod
    {
        public bool enable { get; set; }

        public string @namespace { get; set; }
    }
}
