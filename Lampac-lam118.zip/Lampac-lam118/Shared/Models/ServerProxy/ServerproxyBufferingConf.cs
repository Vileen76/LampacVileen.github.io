﻿namespace Shared.Models.ServerProxy
{
    public class ServerproxyBufferingConf
    {
        public bool enable { get; set; }

        public int rent { get; set; }

        public int length { get; set; }

        public int millisecondsTimeout { get; set; }
    }
}
