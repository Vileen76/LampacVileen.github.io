﻿namespace Shared.Models.ServerProxy
{
    public class ServerproxyCacheConf
    {
        public bool img { get; set; }

        public bool img_rsize { get; set; }

        public bool hls { get; set; }

        public string hls_pattern { get; set; }
    }
}
