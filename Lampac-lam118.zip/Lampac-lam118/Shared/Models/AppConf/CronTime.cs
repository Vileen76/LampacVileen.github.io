﻿namespace Lampac.Models.AppConf
{
    public class CronTime
    {
        public int updateLampaWeb;

        public int clearCache;

        public int updateTrackers;
    }
}
