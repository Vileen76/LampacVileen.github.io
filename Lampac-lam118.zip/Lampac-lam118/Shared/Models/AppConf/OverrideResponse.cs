﻿namespace Lampac.Models.AppConf
{
    public class OverrideResponse
    {
        public string pattern { get; set; }

        public string action { get; set; }

        public string type { get; set; }

        public string val { get; set; }
    }
}
