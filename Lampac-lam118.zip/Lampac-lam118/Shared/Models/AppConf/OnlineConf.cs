﻿namespace Lampac.Models.AppConf
{
    public class OnlineConf
    {
        public string findkp { get; set; }

        public bool checkOnlineSearch { get; set; }


        public string component { get; set; }

        public string name { get; set; }

        public string description { get; set; }

        public bool version { get; set; }


        public string apn { get; set; }
    }
}
