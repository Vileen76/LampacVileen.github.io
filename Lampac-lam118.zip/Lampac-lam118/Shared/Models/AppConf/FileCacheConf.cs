﻿namespace Lampac.Models.AppConf
{
    public class FileCacheConf
    {
        public int maxcachesize { get; set; }

        public int intervalclear { get; set; }

        public int html { get; set; }

        public int img { get; set; }

        public int torrent { get; set; }

        public int hls { get; set; }
    }
}
