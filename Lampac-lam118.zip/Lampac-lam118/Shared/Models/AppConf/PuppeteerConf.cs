﻿namespace Shared.Models.AppConf
{
    public class PuppeteerConf
    {
        public bool enable { get; set; }

        public bool keepopen { get; set; }

        public string executablePath { get; set; }
    }
}
