﻿namespace Shared.Models.AppConf
{
    public class RchConf
    {
        public bool enable { get; set; }

        public int keepalive { get; set; }
    }
}
