﻿namespace Lampac.Models.AppConf
{
    public class FfprobeSettings
    {
        public bool enable { get; set; }

        public string tsuri { get; set; }
    }
}
