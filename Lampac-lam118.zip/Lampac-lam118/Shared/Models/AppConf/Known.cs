﻿namespace Lampac.Models.AppConf
{
    public class Known
    {
        public string ip { get; set; }

        public int prefixLength { get; set; }
    }
}
