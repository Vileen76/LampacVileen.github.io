﻿namespace Shared.Models.Proxy
{
    public class ProxyManagerModel
    {
        public string proxyip { get; set; }

        public int errors { get; set; }
    }
}
