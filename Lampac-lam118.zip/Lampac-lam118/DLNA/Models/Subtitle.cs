﻿namespace Lampac.Models.DLNA
{
    public class Subtitle
    {
        public string label { get; set; }

        public string url { get; set; }
    }
}
